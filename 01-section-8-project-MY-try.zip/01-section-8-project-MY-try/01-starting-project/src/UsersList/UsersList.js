import User from "./User.js";
import Card from "../UI/Card/Card";
import styles from "./UserList.module.css";

const UsersList = (props) => {
  return (
    <div >
      <Card className="usersList">
        {props.users.map((user) => (
          <User
            key={user.id}
            id={user.id}
            name={user.name}
            age={user.age}
          ></User>
        ))}
      </Card>
    </div>
  );
};

export default UsersList;
