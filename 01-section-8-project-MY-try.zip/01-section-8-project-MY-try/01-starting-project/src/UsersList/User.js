import styles from "./User.module.css";
import Card from "../UI/Card/Card";

const User = (props) => {
  return (
    <div>
      <Card className="user">
        <p className={`${styles["test-color"]}`}>
          {props.name} ({props.age} years old)
        </p>
      </Card>
    </div>
  );
};

export default User;
