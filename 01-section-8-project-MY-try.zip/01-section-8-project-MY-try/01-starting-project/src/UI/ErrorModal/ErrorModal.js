import styles from "./ErrorModal.module.css";
import Button from "../Button/Button";
import Card from "../Card/Card";

const ErrorModal = (props) => {
  return (
    <div>
      <Card className="error">
        <div className={styles.header}>
          <h2>{props.title}</h2>
        </div>
        <div className={styles.content}>
          <p>{props.message}</p>
        </div>
        <Button className={styles.actions}>Okay</Button>
      </Card>
    </div>
  );
};

export default ErrorModal;
