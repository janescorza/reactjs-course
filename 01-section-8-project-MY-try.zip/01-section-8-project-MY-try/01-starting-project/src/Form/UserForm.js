import React, { useState } from "react";
import Button from "../UI/Button/Button.js";
import styles from './UserForm.module.css';

const UserForm = (props) => {
  const [enteredUsername, setEnteredUsername] = useState("");
  const [enteredAge, setEnteredAge] = useState("");

  const formSubmitHandler = (event) => {
    event.preventDefault();
    let alertMessage = "";
    //Checking conditions to launch alert dialog
    if (enteredUsername === "" && enteredAge === "") {
      alertMessage = "both empty";
    } else if (enteredUsername === "") {
      alertMessage = "username empty";
    } else if (enteredAge === "" || enteredAge < 0) {
      alertMessage = "Invalid age";
    }
    if (alertMessage) {
      console.log(alertMessage);
      return;
    }
    const newUser = {
      name: enteredUsername,
      age: enteredAge,
    };
    props.addUser(newUser);
  };

  const userNameInputChangeHandler = (event) => {
    setEnteredUsername(event.target.value);
  };

  const ageInputChangeHandler = (event) => {
    setEnteredAge(event.target.value);
  };

  return (
    <div>
      <form onSubmit={formSubmitHandler}>
        <div>
          <h4 className={styles.h4}>Username</h4>
          <input onChange={userNameInputChangeHandler}></input>
          <h4 className={styles.h4}>Age (Years)</h4>
          <input type="number" className={styles.input} onChange={ageInputChangeHandler}></input>
        </div>
        <Button type="submit">Add User</Button>
      </form>
    </div>
  );
};

export default UserForm;
