import React, { useState } from "react";
import "./ExpenseForm.css";

const ExpenseForm = (props) => {
  const [enteredTitle, setEnteredTitle] = useState("");
  const [enteredAmount, setEnteredAmount] = useState("");
  const [enteredDate, setEnteredDate] = useState("");
  // const [formStatus, setFormStatus] = useState("hidden")

  //   const [userInput, setUserInput] = useState({
  //     enteredTitle: "",
  //     enteredAmount: "",
  //     enteredDate: "",
  //   });

  const titleChangeHandler = (event) => {
    setEnteredTitle(event.target.value);
    // setUserInput({
    //     ...userInput,
    //     enteredTitle: event.target.value,
    //   });
    //   setUserInput((prevState) => {
    //     return {
    //         ...prevState,enteredTitle : event.target.value
    //     }
    //   });
    console.log("enteredTitle is: " + enteredTitle);
  };
  const amountChangeHandler = (event) => {
    setEnteredAmount(event.target.value);
    // setEnteredAmount({
    //   ...userInput,
    //   enteredAmount: event.target.value,
    // });
    console.log("enteredAmount is: " + enteredAmount);
  };
  const dateChangeHandler = (event) => {
    setEnteredDate(event.target.value);
    // setEnteredDate({
    //   ...userInput,
    //   enteredDate: event.target.value,
    // });
    console.log("enteredDate is: " + enteredDate);
  };
  const submitHandler = (event) => {
    event.preventDefault();
    const expenseData = {
      title: enteredTitle,
      amount: +enteredAmount,
      date: new Date(enteredDate), //Parse date string into date object
    };
    setEnteredTitle('');
    setEnteredAmount('');
    setEnteredDate('');
    props.onSaveExpenseData(expenseData);
  };

  // const statusHandler = (event) => {
  //   setFormStatus((prevState)=>{
  //     if (prevState === "hidden") return "shown";
  //     else return "hidden"
  //   })
  // }

  // if(formStatus === "hidden"){
  //   return(
  //     <div className="new-expense__controls_launch">
  //       <button type="button" onClick={statusHandler}>Add new Expense</button>
  //     </div>
  //   )
  // }

  return (
    <form onSubmit={submitHandler}>
      <div className="new-expense__controls">
        <div className="new-expense__control">
          <label>Title</label>
          <input
            type="text"
            value={enteredTitle}
            onChange={titleChangeHandler}
          />
        </div>
        <div className="new-expense__control">
          <label>Amount</label>
          <input
            type="number"
            value={enteredAmount}
            min="0.01"
            step="0.01"
            onChange={amountChangeHandler}
          />
        </div>
        <div className="new-expense__control">
          <label>Date</label>
          <input
            type="date"
            value={enteredDate}
            min="2019-01-01"
            max="2022-12-31"
            onChange={dateChangeHandler}
          />
        </div>
      </div>
      <div className="new-expense__actions">
        <button type="button" onClick={props.onCancel}>Cancel</button>
        <button type="submit">Add Expense</button>
      </div>
    </form>
  );
};

export default ExpenseForm;
